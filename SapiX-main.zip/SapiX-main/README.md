## ⚠️If you publish an executor with SapiX or modify it, don’t forget to give me credits! I really appreciate it.⚠️

# SapiX
**(Saturn Api Xeno)**

 SapiX is an Api based on Xeno, open source and easy to use, allowing anyone to quickly create their exploits, securely and in a safe way.

- UNC: 83%
- Level: 3
- Xeno.dll
- Only works on roblox web version

# Functions

SapiX.Api.Inject();

SapiX.Api.Execute();

SapiX.Api.IsRobloxOpen();

SapiX.Api.IsInjected();

SapiX.Api.KillRoblox();

SapiX.Api.SetCustomInjectionNotification(string title, string text, string idIcon, string duration)

SapiX.Api.SetCustomUserAgent(string Name);

SapiX.Api.SetCustomNameExecutor(string Name, string Version);

# Examples

SapiX.Api.SetCustomInjectionNotification("Test executor", "Injected successfully!", "93547137238535", "3");

SapiX.Api.SetCustomNameExecutor("Test executor", "v1.0.0");

SapiX.Api.SetCustomUserAgent("Test executor");

If you don't use these customization functions, or if you want to leave a parameter empty, default values will be applied. To leave a parameter empty for example, the icon, use an empty string like this: "".
These functions go in the constructor.

## For the custom icon you must use an image, not a decal!!

# How to make an executor with SapiX

https://www.youtube.com/watch?v=-QB6N0mTpQ4&t=22s
(It doesn't show how to use the new customization functions)

# Credits

Xeno

https://discord.gg/xeno-now

https://www.xeno.onl
